<?php
header('Content-Type: application/json');

// Function to read authentication information
function read_auth_and_username() {
    try {
        $file = fopen('akun.txt', 'r');
        $content = fgets($file);
        $tokenBarier = rtrim($content, "\n");
        $content = fgets($file);
        $myUname = rtrim($content, "\n");
        fclose($file);

        return array($tokenBarier, $myUname);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array("error" => "Terjadi pengecualian: $e"));
        exit();
    }
}

// Function to set up HTTP request
function setupRequest($METHOD, $URL, $HEADERS, $PAYLOAD = null) {
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $METHOD);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $HEADERS);
        if ($PAYLOAD) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $PAYLOAD);
        }
        $response = curl_exec($ch);
        if (!$response) {
            throw new Exception(curl_error($ch));
        }
        curl_close($ch);
        return json_decode($response, true);
    } catch (Exception $e) {
        error_log("Curl error: " . $e->getMessage());
        return null;
    }
}

// Function to follow a user
function followUser($fid, $tokenBarier) {
    $urlFollow = "https://client.warpcast.com/v2/follows";
    $headers = array(
        'authority: client.warpcast.com',
        'accept: */*',
        'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type: application/json; charset=utf-8',
        'origin: https://warpcast.com',
        'referer: https://warpcast.com/',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'authorization: Bearer ' . $tokenBarier
    );

    $payload = json_encode(array("targetFid" => $fid));

    $response = setupRequest("PUT", $urlFollow, $headers, $payload);

    return $response;
}

// Function to get user profile by username
function getUserProfileByUsername($username, $tokenBarier) {
    $urlGetProfile = "https://client.warpcast.com/v2/user-by-username?username=" . urlencode($username);
    $headers = array(
        'authority: client.warpcast.com',
        'accept: */*',
        'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type: application/json; charset=utf-8',
        'origin: https://warpcast.com',
        'referer: https://warpcast.com/',
        'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'authorization: Bearer ' . $tokenBarier
    );

    return setupRequest("GET", $urlGetProfile, $headers, null);
}

// Main script logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_GET['action'];
    $username = $_POST['username'];

    if ($action === "follow") {
        list($tokenBarier, $myUname) = read_auth_and_username();

        // Get user profile by username
        $profile = getUserProfileByUsername($username, $tokenBarier);

        if (!isset($profile['result']['fid'])) {
            $result = array("result" => "Failed to get fid for user: " . $username);
        } else {
            $fid = $profile['result']['fid'];

            // Follow the user
            $response = followUser($fid, $tokenBarier);

            if ($response === null) {
                $result = array("result" => "Failed to follow user: " . $username);
            } else {
                $result = array("result" => "Successfully followed user: " . $username);
            }
        }

        echo json_encode($result);
    }
}
?>