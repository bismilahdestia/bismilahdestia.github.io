<?php
// Function to read authentication information
function read_auth_and_username() {
    try {
        $file = fopen('akun.txt', 'r');
        if (!$file) {
            throw new Exception('Unable to open akun.txt');
        }
        $content = fgets($file);
        $tokenBarier = rtrim($content, "\n");
        $content = fgets($file);
        $myUname = rtrim($content, "\n");
        fclose($file);

        return array($tokenBarier, $myUname);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array("error" => "Error reading authentication: " . $e->getMessage()));
        exit();
    }
}

// Function to read cast URLs
function read_cast_urls() {
    try {
        $file = fopen('list-cast.txt', 'r');
        if (!$file) {
            throw new Exception('Unable to open list-cast.txt');
        }
        $urls = [];
        while (!feof($file)) {
            $line = fgets($file);
            if (strpos($line, 'http') === 0) {
                $urls[] = rtrim($line, "\n");
            }
        }
        fclose($file);
        return $urls;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array("error" => "Error reading cast URLs: " . $e->getMessage()));
        exit();
    }
}

// Function to set up HTTP request
function setupRequest($METHOD, $URL, $HEADERS, $PAYLOAD) {
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $METHOD);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $HEADERS);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $PAYLOAD);
        $response = curl_exec($ch);
        if (!$response) {
            throw new Exception(curl_error($ch));
        }
        curl_close($ch);
        return json_decode($response, true);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array("error" => "Error making HTTP request: " . $e->getMessage()));
        exit();
    }
}

// Function to perform batch like and comment operation
function doBatchLikeAndComment($myUname, $tokenBarier, $word) {
    $file_path = "list-cast.txt";
    $count = 0;
    $listNotLike = [];
    $successMessages = [];

    $file = fopen($file_path, "r");
    if (!$file) {
        http_response_code(500);
        echo json_encode(array("error" => "Failed to open list-cast.txt"));
        exit();
    }

    echo "<h2>Live Liking and Commenting Process:</h2><hr>";

    while (!feof($file)) {
        $line = fgets($file);
        preg_match('/(https?:\/\/\S+)/', $line, $matches);
        if (!empty($matches)) {
            $line = $matches[0];
        } else {
            continue;
        }

        $parsed_url = parse_url($line);
        if (!isset($parsed_url['scheme']) || !isset($parsed_url['host'])) {
            continue;
        }

        $path_parts = explode("/", $parsed_url['path']);
        if (count($path_parts) < 3) {
            continue;
        }

        $username = $path_parts[1];
        $identifier = substr($path_parts[2], 0, 10);

        if ($username == $myUname) {
            continue;
        }

        $getHash = setupRequest("GET", "https://client.warpcast.com/v2/user-thread-casts?castHashPrefix=$identifier&username=$username&limit=15", array(
            'authority: client.warpcast.com',
            'accept: */*',
            'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type: application/json; charset=utf-8',
            'origin: https://warpcast.com',
            'referer: https://warpcast.com/',
            'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'authorization: Bearer ' . $tokenBarier
        ), "");

        if ($getHash && isset($getHash['result']) && isset($getHash['result']['casts'])) {
            foreach ($getHash['result']['casts'] as $hash_data) {
                $hash = $hash_data['hash'];
                if (strpos($hash, $identifier) === false) {
                    continue;
                }

                $headers = array(
                    'authority: client.warpcast.com',
                    'accept: */*',
                    'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                    'content-type: application/json; charset=utf-8',
                    'origin: https://warpcast.com',
                    'referer: https://warpcast.com/',
                    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                    'authorization: Bearer ' . $tokenBarier
                );
                $payload_hash = json_encode(array("castHash" => $hash));

                $alreadyLiked = false;
                foreach ($successMessages as $message) {
                    if (strpos($message, $hash) !== false) {
                        $alreadyLiked = true;
                        break;
                    }
                }

                if (!$alreadyLiked) {
                    $count++;
                    sleep(20); 

                    try {
                        $response = setupRequest("PUT", "https://client.warpcast.com/v2/cast-likes", $headers, $payload_hash);
                        if ($response && isset($response['result']) && isset($response['result']['like'])) {
                            $cast_hash = $response['result']['like']['castHash'];
                            $liker_fid = $response['result']['like']['reactor']['fid'];
                            $successMessage = "SUKSES ONYO: $line"; 
                            $successMessages[] = $successMessage;
                            echo "<p style='color: green;'>$successMessage</p>"; 
                        } else {
                            $listNotLike[] = $line;
                            echo "<p style='color: red;'>GAGAL ONYO: $line</p>"; 
                        }
                    } catch (Exception $e) {
                        $listNotLike[] = $line;
                        echo "<p style='color: red;'>GAGAL ONYO: $line</p>"; 
                    }

                    // Commenting
                    $comment_payload = json_encode(array("text"=> $word[array_rand($word)], "parent" => array("hash" => $hash)));

                    try {
                        $response = setupRequest("POST", "https://client.warpcast.com/v2/casts", $headers, $comment_payload);
                        if ($response && isset($response['success'])) {
                            $successMessage = "SUKSES KOMEN ONYO: $line"; // Changed success message for comment
                            $successMessages[] = $successMessage;
                            echo "<p style='color: blue;'>$successMessage</p>"; 
                        } else {
                            echo "<p style='color: red;'>Failed to add comment to $line</p>"; 
                        }
                    } catch (Exception $e) {
                        echo "<p style='color: red;'>Failed to add comment to $line</p>"; 
                    }
                }
            }
        } else {
            $listNotLike[] = $line;
            echo "<p style='color: red;'>GAGAL ONYO: $line</p>"; 
        }

        ob_flush();
        flush();
    }
    fclose($file);

    echo "<hr>";
    echo "<h3>Summary:</h3>";
    echo "<p>Total Tasks: $count</p>";
    echo "<p>Total Not Liked: " . count($listNotLike) . "</p>";
    echo "<p>Total Success: " . count($successMessages) . "</p>";
}

// Main function to run the script
function main() {
    list($tokenBarier, $myUname) = read_auth_and_username();
    $cast_urls = read_cast_urls();
    $word = ["Nice!", "Great work!", "Awesome!", "Amazing!", "Keep it up!", "Your work is truly amazing!", "Your hard work deserves applause!", "Your achievements are outstanding!", "You're absolutely fantastic!", "You're truly inspiring!", "Take the time to appreciate.", "You're truly exceptional!", "You're making a big difference!", "Stay motivated and keep innovating!", "Your attitude is inspiring others!", "Create with dedication!", "You're doing fantastic!", "You're doing a superb job!", "Your effort is commendable!", "You're making remarkable progress!", "You're a shining example!", "You're a true asset!", "You're on the right track!", "Your dedication is admirable!", "Your commitment is impressive!", "You're on fire with your work!", "You're exceeding expectations!", "You're a true rockstar!", "You're an inspiration to others!", "Your work ethic is unmatched!", "You're unstoppable!", "You're a role model!", "You're a valuable team member!", "You're a force to be reckoned with!", "You're an absolute legend!", "Your talent knows no bounds!", "You're making waves!", "You're on top of your game!", "You're a true professional!", "You're a true champion!", "You're destined for greatness!", "You're a master of your craft!", "You're a beacon of success!", "You're paving the way for others!", "You're an invaluable asset to the team!", "You're setting the bar high!", "You're making dreams a reality!", "You're a true inspiration to us all!"];

    // Run batch like and comment mode
    doBatchLikeAndComment($myUname, $tokenBarier, $word);
}

// Execute main function
main();
?>