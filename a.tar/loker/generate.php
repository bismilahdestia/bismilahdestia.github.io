<!DOCTYPE html>
<html>
<head>
    <title>Surat Lamaran Pekerjaan</title>
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nama_perusahaan = $_POST['nama_perusahaan'];
        $posisi = $_POST['posisi'];
        $keahlian = $_POST['keahlian'];
        $tanggal = date("d F Y");

        // Template surat lamaran
        $template = "Kepada Yth.,<br>
        HRD ($nama_perusahaan)<br>
        di Tempat<br><br>
        
        Dengan hormat,<br><br>
        
        Saya yang bertanda tangan di bawah ini:<br><br>
        
        Nama: Destia Ningsih<br>
        Tempat, Tanggal Lahir: Bandung, 23 Desember 2002<br>
        Alamat: Jln. Cijawura Hilir RT 05 RW 11 No 63<br>
        Pendidikan: Multimedia - SMK Negeri 14 Bandung<br>
        No. Telp: 0895-4130-19789<br>
        Email: destiaaan23@gmail.com<br><br>
        
        Dengan ini mengajukan lamaran pekerjaan untuk posisi $posisi di $nama_perusahaan<br><br>
        
        Saya memiliki keahlian dalam $keahlian, yang saya yakini akan sangat berguna dalam menjalankan tugas-tugas di posisi yang saya lamar ini.<br><br>
        
        Sebagai bahan pertimbangan, saya lampirkan:<br>
        1. Daftar Riwayat Hidup<br>
        2. Scan Ijazah<br>
        3. Scan Transkip Nilai<br>
        4. Scan Paklaring<br>
        5. Scan KTP<br>
        6. Pas Foto<br><br>
        
        Demikian surat lamaran ini saya buat dengan sebenar-benarnya. Besar harapan saya untuk dapat diberikan kesempatan wawancara agar saya dapat menjelaskan lebih rinci tentang potensi dan kemampuan saya.<br><br>
        
        Atas perhatian dan kesempatan yang diberikan bapak/ibu, saya ucapkan terima kasih.<br><br>
        
        Hormat saya,<br>
        Destia Ningsih<br>
        destiaaan23@gmail.com<br>";

        echo $template;
    }
    ?>
</body>
</html>